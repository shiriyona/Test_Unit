﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coronaTest
{
    class schoolZoom
    {
        public int checkZoomHour(double age)
        {
            int hour=1;
            if (age > 6 && age < 7)
            {
                hour = 8;

            }
            if (age > 7 && age < 8)
            {
                hour = 9;
            }
            if (age > 8 && age < 9)
            {
                hour = 10;
            }
            return hour;
        }
        public bool checkPresence(string name)
        {
            bool presence = false;
            foreach(char letter in name)
            {
                if(letter=='y')
                {
                    presence = true;                 
                }
            }
            return presence;
        }
        public string[] getSizeReturnName(int size)
        {
            string[] myStrings = new string[size];
            for (int i=0; i<size; i++)
            {
                myStrings[i] ="Yeled"+(i+1);   
            }
            return myStrings;
        }
    }
}
