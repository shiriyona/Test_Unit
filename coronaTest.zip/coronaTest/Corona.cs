﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coronaTest
{
    class Corona
    {
        public double GetTraffiMarkLight(string city)
        {
            double res = 4.2;
            switch (city)
            {
                case "Bnei Brak":
                    res = 7.8;
                    break;
                case "Tiberias":
                    res = 5.4;
                    break;
                case "Lud":
                    res = 6.5;
                    break;
                case "Ramat Gan":
                    res = 9;
                    break;
                case "Tell Aviv":
                    res = 5.1;
                    break;
                case "Jerusalem":
                    res = 6.8;
                    break;
            }
            return res;
        }
        public string GetColorMark(double mark)
        {
            string color = "red";
            if (mark >= 7)
            {
                color = "red";
            }
            if (mark < 7 && mark >= 6)
            {
                color = "orange";
            }
            if (mark < 6)
            {
                color = "green";
            }
            return color;
        }
        public string GetCityMarkColor(string city)
        {
            double mark = GetTraffiMarkLight(city);
            string color = GetColorMark(mark);
            return color;
        }
        public int AreaOfStore(int area)
        {
            int people = area / 20;
            return people;
        }
        public int CheckAge(int[] myArray)
        {
            int counter = 0;
            foreach (int item in myArray)
            {
                if (item > 50)
                {
                    counter++;
                }

            }
           /* int counter = 0;
            for (int i = 0; i < myArray.Length; i++)

            {
                if (myArray[i] > 50)
                {
                    counter++;
                }
            }*/
            return counter;
        }
    }    

     
        
                                
    
}
