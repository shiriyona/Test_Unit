﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace coronaTest
{
    [TestClass]
    public class CoronaUnitTest
    {
        [TestMethod]
        public void TestGetTraffiMcarkLight()
        {
            Corona corona = new Corona();
            string param1 = "Bnei Brak";
            double expected1 = 7.8;
            double actual1 = corona.GetTraffiMarkLight(param1);
             Assert.AreEqual(expected1, actual1, 0, "THE RESUELT IS INCORRECT");

            string param2 = "Tiberias";
            double expected2 = 5.4;
            double actual2 = corona.GetTraffiMarkLight(param2);
            Assert.AreEqual(expected2, actual2, 0, "THE RESUELT IS INCORRECT");

            string param3 = "Ramat Gan";
            double expected3 = 9;
            double actual3 = corona.GetTraffiMarkLight(param3);
            Assert.AreEqual(expected3, actual3, 0, "THE RESUELT IS INCORRECT");
            string param4 = "Jerusalem";
            double actual4 = corona.GetTraffiMarkLight(param4);
            double expected4 = 6.8;
            Assert.AreEqual(expected4, actual4, 0, "THE RESUELT IS INCORRECT");         
        }
        [TestMethod]
        public void GetColorMark()
        {
            Corona corona = new Corona();
            double param1 = 8;
            string expected1 = "red";
            string actual1 = corona.GetColorMark(param1);
            Assert.AreEqual(expected1, actual1, "THE RESUELT IS INCORRECT");
            double param2 = 6.5;
            string expected2 = "orange";
            string actual2= corona.GetColorMark(param2);
            Assert.AreEqual(expected2, actual2, "THE RESUELT IS INCORRECT");
            double param3 = 3;
            string expected3 = "green";
            string actual3 = corona.GetColorMark(param3);
            Assert.AreEqual(expected3, actual3, "THE RESUELT IS INCORRECT");
        }
        [TestMethod]
        public void GetCityMarkColor()
        {
            Corona corona = new Corona();
            string param1 = "Lud";
            string expected1 = "orange";
            string actual1 = corona.GetCityMarkColor(param1);
            Assert.AreEqual(expected1, actual1, "THE RESUELT IS INCORRECT");
            string param2 = "Ramat Gan";
            string expected2 = "red";
            string actual2 = corona.GetCityMarkColor(param2);
            Assert.AreEqual(expected2, actual2, "THE RESUELT IS INCORRECT");
        }
        [TestMethod]
        public void AreaOfStore()
        {
            Corona corona = new Corona();
            int param1 = 101;
            int expected1 = 5;
            int actual1 = corona.AreaOfStore(param1);
            Assert.AreEqual(expected1, actual1, 0, "THE RESUELT IS INCORRECT");

        }
        [TestMethod]
        public void CheckAge()
        {
            Corona corona = new Corona();
            int[] param1 = new int[] {30, 67, 23, 76, 43, 19, 45, 52, 32, 20};
            int expected1 = 3;
            int actual1 = corona.CheckAge(param1);
            Assert.AreEqual(expected1, actual1, 0, "THE RESUELT IS INCORRECT");
        }
       
    }
    [TestClass]
    public class schoolTestUnitTest
    {
        [TestMethod]
        public void checkZoomHour()
        {
            schoolZoom mySchoolZoom = new schoolZoom();
            double param1 = 6.4;
            int expected1 = 8;
            int actual1 = mySchoolZoom.checkZoomHour(param1);
            Assert.AreEqual(expected1, actual1, "THE RESUELT IS INCORRECT");
            double param2 = 8.1;
            int expected2 = 10;
            int actual2 = mySchoolZoom.checkZoomHour(param2);
            Assert.AreEqual(expected2, actual2, "THE RESUELT IS INCORRECT");
        }
        [TestMethod]
        public void checkPresence()
        {
            schoolZoom mySchoolZoom = new schoolZoom();
            string param1 = "yossi";
            bool expected1 = true;
            bool actual1 = mySchoolZoom.checkPresence(param1);
            Assert.AreEqual(expected1, actual1, "THE RESUELT IS INCORRECT");
            string param2 = "ron";
            bool expected2 = false;
            bool actual2 = mySchoolZoom.checkPresence(param2);
            Assert.AreEqual(expected2, actual2, "THE RESUELT IS INCORRECT");
        }
        [TestMethod]
        public void getSizeReturnName()
        {
            
            schoolZoom mySchoolZoom = new schoolZoom();
            int param1 = 3;
            string[] expected1 = {"Yeled1", "Yeled2", "Yeled3"};
            string[] actual1 = mySchoolZoom.getSizeReturnName(param1);
            CollectionAssert.AreEqual(expected1, actual1, "THE RESUELT IS INCORRECT");
            
        }

    }
}


